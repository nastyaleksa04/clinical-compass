# Knowledge Base v2 · Clinical Compass (pilot)

Export date: 2026-10-24
Scope: 2 conditions — GAD (457_3) + Depression (301_3)

## Layout (Latin paths only)

```
kb_v2/
  README.md
  qa_report.json
  sources.jsonl
  entities/
    conditions.jsonl
    medications.jsonl          # includes label_status: present|missing
    medication_cards.jsonl
    safety_rules.jsonl         # trigger formalized + empty positive/negative_tests
    scales.jsonl
    eval_cases.jsonl
    patient_model.jsonl
    chunks.jsonl               # managed chunks <=1500 chars, overlap 200
  raw/                         # empty in pilot; put source PDFs here with Latin names
```

## Fixes vs previous pack

1. Latin-only paths (no Cyrillic folder/file names).
2. chunks.jsonl added with controlled chunking.
3. medications.label_status explicitly marks missing GRLS cards.
4. safety_rules.trigger is a structured object (best-effort parse) + trigger_raw; test arrays present but empty.
5. qa_report.json documents coverage gaps vs full acceptance criteria.

## Notes

- Pilot intentionally covers 2 of 8-10 condition groups.
- Cyrillic appears only inside JSON string values.
- UI attributes (banner color, sound) are out of scope for KB.
